/* global instantsearch algoliasearch */

const search = instantsearch({
  indexName: 'index_wine',
  searchClient: algoliasearch('39YA0X46OD', 'cea3ac6b033755ecaf03f7a8788c5abf'),
});
/*Linked with my application ID and API key from Algolia   */
search.addWidget(
  instantsearch.widgets.searchBox({
    container: '#searchbox',
  })
);
/*Kept the search bar */
search.addWidget(
  instantsearch.widgets.clearRefinements({
    container: '#clear-refinements',
  })
);
/*Kept the button just in case of developpement of selection */

search.addWidget(
  instantsearch.widgets.refinementList({
    container: '#brand-list',
    attribute: 'brand',
  })
);
/*the listing */

search.addWidget(
  instantsearch.widgets.hits({
    container: '#hits',
    templates: {
      item: `
      
        <div>
          <img src="{{image}}" align="left" alt="{{name}}" />
          <div class="hit-name">
            {{#helpers.highlight}}{ "attribute": "name" }{{/helpers.highlight}}
          </div>        
          <div class="hit-description">
            {{#helpers.highlight}}{ "attribute": "description" }{{/helpers.highlight}}
          </div>
                 <div class="hit-domain">
            {{#helpers.highlight}}{ "attribute": "domain" }{{/helpers.highlight}}
          </div>  
           <div class="hit-year">\Year: {{year}}
           </div>
        </div>
      `,
      /*the parameters to display according to query: Name, domain and year*/
    },
  })
);

search.addWidget(
  instantsearch.widgets.pagination({
    container: '#pagination',
  })
);

search.start();
